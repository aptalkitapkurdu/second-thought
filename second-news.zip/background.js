
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "analyze_tweet") {
    fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer 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"
      },
      body: JSON.stringify({
        model: "ft:gpt-4o-mini-2024-07-18:personal:mixed-data-mil:Ankery8o",
        messages: [
          {
            role: "system",
            content: "Sen bir medya okuryazarlığı eğitmeni yapay zekasın. Aşağıdaki haber metnini analiz et. Manipülatif mi?: Evet/Hayır. Sebep: kısa açıklama. Özet: 2-3 cümlelik haber özeti."
          },
          {
            role: "user",
            content: request.text
          }
        ]
      })
    })
    .then(res => res.json())
    .then(data => sendResponse({ message: data.choices?.[0]?.message?.content || "Cevap alınamadı." }))
    .catch(() => sendResponse({ message: "API hatası." }));
    return true;
  }
});
