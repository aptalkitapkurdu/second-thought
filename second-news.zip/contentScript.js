
function extractNewsText() {
  const article = document.querySelector("article");
  let content = article ? article.innerText.trim() : "";
  if (!content || content.length < 100) {
    const alt = [];
    const h1 = document.querySelector("h1");
    if (h1) alt.push(h1.innerText);
    document.querySelectorAll("p").forEach(p => alt.push(p.innerText));
    content = alt.join("\n").trim();
  }
  return content.slice(0, 4000);
}

function createBubble() {
  if (document.getElementById("st-bubble")) return;

  const bubble = document.createElement("div");
  bubble.id = "st-bubble";
  bubble.innerText = "ST";
  document.body.appendChild(bubble);

  bubble.addEventListener("click", () => {
    const existing = document.querySelector("#st-response");
    if (existing) {
      existing.remove();
      return;
    }

    const box = document.createElement("div");
    box.id = "st-response";
    box.innerText = "Analiz ediliyor...";
    document.body.appendChild(box);

    chrome.runtime.sendMessage({ action: "analyze_tweet", text: extractNewsText() }, res => {
      box.innerText = res.message || "Cevap alınamadı.";
    });
  });
}

window.addEventListener("load", () => {
  setTimeout(createBubble, 1200);
});
